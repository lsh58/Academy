<?php
    //더하기
    $sum = 5 + 5; // 5+5를 연산한 값이 변수 sum에 대입
    echo "5 더하기 5 는 ".$sum;
    echo "<br>";

    //빼기
    $minus = 5 - 2; // 5-2를 연산한 값이 변수 minus에 대입
    echo "5 빼기 2 는 ".$minus;
    echo "<br>";

    //곱하기
    $mul = 5 * 3; //5*3을 연산한 값이 변수 mul에 대입
    echo "5 곱하기 3 은 ".$mul;
    echo "<br>";

    //나누기
    $division = 6 / 3;  // 6/3을 연산한 값이 변수 division에 대입
    echo "6 나누기 3 은 ".$division;
    echo "<br>";

    //나머지
    $rest = 5 % 3; // 5%3을 연산한 값이 변수 rest에 대입
    echo "5 나누기 3의 나머지 값은 ".$rest;
?>