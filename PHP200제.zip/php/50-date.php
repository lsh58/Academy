<?php
    echo "현재 시간은 ".date("Y년 m월 d일 H시 i분 s초", time());
?>