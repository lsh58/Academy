<!doctype html>
<html>
<head>
<script>
    data = {userID:'mickey'};
    console.log(data.userID);
</script>
</head>
</html>