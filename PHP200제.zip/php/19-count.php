<?php
    $arr = range(1,10,3);
    echo "배열 arr의 값의 수는 : ".count($arr);
?>
