<!DOCTYPE html>
<html>
<head>
<title>INPUT태그 type='url'</title>
</head>
<body>
<form name="폼 태그 이름" method="데이터 전송 방식" action="정보를 보낼 주소">
    <input type="url" name="userWebSite" placeholder="운영중인 사이트 입력" />
    <input type="submit" value="전송" />
</form>
</body>
</html>