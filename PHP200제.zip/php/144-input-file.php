<!DOCTYPE html>
<html>
<head>
<title>INPUT태그 type='url'</title>
</head>
<body>
<form name="" method="" action="" enctype="multipart/form-data">
    파일 : <input type="file" name="attachedFile" />
</form>
</body>
</html>