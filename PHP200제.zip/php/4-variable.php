<?php
    $num = 4;
    echo "변수 num의 값은 {$num} 입니다.";
?>