<?php
    class a{
        protected function hello(){
            echo 'hello world';
        }
    }

    $a = new a;
    $a->hello();
?>