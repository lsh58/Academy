<!DOCTYPE html>
<html>
<head>
<title>INPUT태그 type='password'</title>
</head>
<body>
<form name="폼 태그 이름" method="데이터 전송 방식" action="정보를 보낼 주소">
    <input type="password" name="userPw" placeholder="비밀번호 입력" />
</form>
</body>
</html>