<!DOCTYPE html>
<html>
<head>
<title>textarea태그</title>
</head>
<body>
<form name="폼 태그 이름" method="데이터 전송 방식" action="정보를 보낼 주소">
    <textarea name="longtext"></textarea>
</form>
</body>
</html>