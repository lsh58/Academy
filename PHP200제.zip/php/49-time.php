<?php
    echo time();
?>