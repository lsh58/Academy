<?php
    do{
        echo "이 문구는 1회만 출력되면 정상입니다.";
    }
    while(false);
?>
