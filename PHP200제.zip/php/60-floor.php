<?php
    $num = 12.68;
    $floor = floor($num);
    echo $floor;
?>