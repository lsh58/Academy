<?php
    echo 'DOCUMENT_ROOT is '.$_SERVER['DOCUMENT_ROOT'].'<br>';
    echo 'HTTP_ACCEPT_LANGUAGE is '.$_SERVER['HTTP_ACCEPT_LANGUAGE'].'<br>';
    echo 'HTTP_HOST is '.$_SERVER['HTTP_HOST'].'<br>';
    echo 'HTTP_USER_AGENT is '.$_SERVER['HTTP_USER_AGENT'].'<br>';
    echo 'SERVER_PORT is '.$_SERVER['SERVER_PORT'].'<br>';
    echo 'SCRIPT_NAME is '.$_SERVER['SCRIPT_NAME'].'<br>';
    echo 'REQUEST_URI is '.$_SERVER['REQUEST_URI'].'<br>';
    echo 'PHP_SELF is '.$_SERVER['PHP_SELF'].'<br>';
    echo 'QUERY_STRING is '.$_SERVER['QUERY_STRING'];
?>