<?php
    $str = 'everdevel';

    echo '첫글자가 영문인 경우 : '.ucfirst($str);
?>