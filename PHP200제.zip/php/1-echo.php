<?php
    echo "안녕하세요.";
    echo '<br>';
    echo '반갑습니다.';
    echo '<br>';
    echo 1234;
    echo '<br>';
    echo "4월 4일에 태어났습니다.";
?>