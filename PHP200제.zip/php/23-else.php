<?php
    $num1 = 3;
    $num2 = 4;

    //두 값이 서로 일치하는지 안하는지 판별
    if ($num1 == $num2){
        echo "변수 num1과 num2의 값은 같습니다.";
    } else {
        echo "변수 num1과 num2의 값은 같지 않습니다.";
    }
?>