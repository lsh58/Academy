<?php
  $num2 = "변수명 num2";
  echo $num2;
  echo "<br>";

  $num3num = "변수명 num3num";
  echo $num3num;
  echo "<br>";

  $_num = "변수명 _num";
  echo $_num;
  echo "<br>";

  $Num = "변수명 Num";
  echo $Num;
  echo "<br>";

  $num = "변수명 num";
  echo $num;
  echo "<br>";

  $str = "선생님은 말씀하셨다. \"여기까지 시험범위입니다.\"";
  echo $str;
?>
