<?php
    setcookie('memberID','everdevel',time()+3600,'/');
?>


