<?php
    $fopen = fopen('helloworld.txt','r+');
    fclose($fopen);
?>