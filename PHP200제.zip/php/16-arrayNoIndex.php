<?php
    $fruit = array();
    $fruit = ['banana', 'water melon', 'grape', 'apple', 'mango'];

    echo $fruit[0]; //banana
    echo "<br>";
    echo $fruit[2]; //grape
?>