<?php
    setcookie('memberID','everdevel',time()-100,'/');
?>