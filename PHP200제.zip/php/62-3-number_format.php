<?php
    $num = 123456789.794;
    echo number_format($num,2,'-',':');
?>