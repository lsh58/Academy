<?php
    $12Num = "변수명 num2";
    echo $12Num;
?>