<?php
    $i = 0;

    do{
        echo "안녕하세요.<br>";
        $i++;
    }

    while($i < 5);
?>
