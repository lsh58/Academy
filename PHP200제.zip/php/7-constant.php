<?php
    //상수 FAVORITE_DOLL에 값 gelatoni를 대입
    define("FAVORITE_DOLL","gelatoni");
    echo "상수 FAVORITE_DOLL의 값은 ".FAVORITE_DOLL."<br>";

    //상수 FAVORITE_DOLL에 값 duffy를 대입
    define("FAVORITE_DOLL","duffy");
    echo "상수 FAVORITE_DOLL의 값은 ".FAVORITE_DOLL;
?>
