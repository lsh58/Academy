<?php
    $fruit = array();
    $fruit = ['grape','strawberry','apple'];

    list($first, $second, $third) = $fruit;
    echo $second;
?>