<?php
    require "noneFile.php";
    echo "페이지에 오류가 없습니다.";
?>
