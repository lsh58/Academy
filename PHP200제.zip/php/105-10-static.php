<?php
    class hello{

        public static function output($word){
            echo $word;
        }
    }

    hello::output("hello world");
?>