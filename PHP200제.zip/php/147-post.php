<?php
    echo "age의 값 : ".$_POST['age'];
    echo '<br>';
    echo "hobby의 값 : ".$_POST['hobby'];
?>