<?php
    echo "age의 값 : ".$_GET['age'];
    echo '<br>';
    echo "hobby의 값 : ".$_GET['hobby'];
?>