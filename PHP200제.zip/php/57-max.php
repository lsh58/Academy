<?php
    $arr = range(1, 1000);
    echo "가장 큰 수 : ".max($arr);
?>