<?php
    $str = "beanscent";
    echo "문자열 수 : ".strlen($str);

    echo '<br>';

    $str = " b e a n s c e n t ";
    echo "문자열 수 : ".strlen($str);
?>