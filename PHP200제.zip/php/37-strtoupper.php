<?php
    $str = "everdevel";
    echo strtoupper($str);
?>