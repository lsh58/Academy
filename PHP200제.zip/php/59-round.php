<?php
    $num = 16.78;
    $round = round($num,1);
    echo $round;
?>