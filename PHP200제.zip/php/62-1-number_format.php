<?php
    $num = 123456789;
    echo number_format($num);
?>