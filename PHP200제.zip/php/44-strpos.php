<?php
    $str = "web development";
    $findStr = 'd';
    $pos = strpos($str,$findStr);
    echo "문자열 {$findStr}의 위치는 : ".$pos;
?>