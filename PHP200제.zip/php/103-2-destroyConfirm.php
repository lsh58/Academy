<?php
    session_start();

    //세션 존재 여부 확인
    echo "<pre>";
    var_dump($_SESSION);
    echo "</pre>";
?>
