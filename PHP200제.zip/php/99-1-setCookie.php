<?php
    setcookie('check','only php folder',time()+3600,'/php/');
?>