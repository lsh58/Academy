<!DOCTYPE html>
<html>
<head>
<title>INPUT태그 type='text'</title>
</head>
<body>
<form name="폼 태그 이름" method="데이터 전송 방식" action="정보를 보낼 주소">
    <input type="text" name="userID" maxlength="12" placeholder="아이디 입력"/>
</form>
</body>
</html>