<?php
    $str = "everdevel";

    //0자리 시작하여 5글자를 자른 후 cutStr에 대입
    $cutStr = substr($str, 0, 5);

    echo $cutStr;
?>