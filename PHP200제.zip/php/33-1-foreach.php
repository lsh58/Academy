<?php
    $memberList = ['미우','유나','민후','해윤'];

    foreach($memberList as $ml){
        echo $ml;
        echo '<br>';
    }
?>