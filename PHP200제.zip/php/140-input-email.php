<!DOCTYPE html>
<html>
<head>
<title>INPUT태그 type='email'</title>
</head>
<body>
<form name="폼 태그 이름" method="데이터 전송 방식" action="정보를 보낼 주소">
    <input type="email" name="userEmail" placeholder="이메일 입력" />
    <input type="submit" value="전송" />
</form>
</body>
</html>