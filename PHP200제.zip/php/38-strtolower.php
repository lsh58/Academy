<?php
    $str = "EVERDEVEL";
    echo strtolower($str);
?>