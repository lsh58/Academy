<?php

    //함수 생성
    function sum($num1, $num2){
        $sum = $num1 + $num2;
        echo $sum;
    }

    //아규먼트 5와 10을 전달
    sum(5, 10);
?>