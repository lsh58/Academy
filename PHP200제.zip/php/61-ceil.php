<?php
    $num = 12.68;
    $ceil = ceil($num);
    echo $ceil;
?>