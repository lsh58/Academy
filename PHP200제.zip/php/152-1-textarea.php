<!DOCTYPE html>
<html>
<head>
<title>TEXTAREA태그 입력폼</title>
</head>
<body>
<form name="textsave" method="post" action="./152-2-textSave.php">
    <textarea name="text"></textarea>
    <input type="submit" value="저장" />
</form>
</body>
</html>