<?php
    $fruit = array();

    array_push($fruit, 'apple', 'banana', 'grape', 'coconut', 'tangerine');

    echo $fruit[0].'<br>';
    echo $fruit[1].'<br>';
    echo $fruit[2].'<br>';
    echo $fruit[3].'<br>';
    echo $fruit[4];
?>