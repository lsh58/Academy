<!doctype html>
<html>
<head>
<script>
    data = {userID:['first','second','third']};
    console.log(data.userID[0]);
    console.log(data.userID[1]);
    console.log(data.userID[2]);
</script>
</head>
</html>