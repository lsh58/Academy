<?php
    $str = "everdevel, tomodevel, startwebcodng";
    echo ucwords($str);

    echo '<br>';

    $str = 'one sugar dream';
    $str = ucwords($str);
    echo $str;
?>