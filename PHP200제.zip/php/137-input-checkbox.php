<!DOCTYPE html>
<html>
<head>
<title>INPUT태그 type='checkbox'</title>
</head>
<body>
<h1>당신의 취미는?</h1>
<form name="폼 태그 이름" method="데이터 전송 방식" action="정보를 보낼 주소">
    음악감상<input type="checkbox" name="myHobby" value="music" />
    영화감상<input type="checkbox" name="myHobby" value="movie" checked/>
    수집<input type="checkbox" name="myHobby" value="collection" />
</form>
</body>
</html>