<!DOCTYPE html>
<html>
<head>
<title>POST방식 데이터 입력폼</title>
</head>
<body>
<form name="test" method="post" action="147-post.php">
    나이 : <input type="text" name="age" />
    취미 : <input type="text" name="hobby" />
    <input type="submit" value="전송" />
</form>
</body>
</html>